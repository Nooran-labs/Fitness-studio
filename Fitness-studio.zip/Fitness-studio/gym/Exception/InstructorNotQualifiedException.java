package gym.Exception;

public class InstructorNotQualifiedException extends Exception {
    public InstructorNotQualifiedException(String message) {
        super(message);
    }
}
