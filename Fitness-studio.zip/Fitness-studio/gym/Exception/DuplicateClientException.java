package gym.Exception;

public class DuplicateClientException extends Exception {
    public DuplicateClientException(String message) {
        super(message);
    }
}
