package gym.management.Sessions;

import gym.customers.Client;
import gym.management.Instructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Session {
    private SessionType sessionType;
    private String DateNTime;
    private ForumType forumType;
    private Instructor instructor;
    private List<Client> clients;

    public Session(SessionType s, String DNT, ForumType f, Instructor i) {
        this.sessionType = s;
        this.DateNTime = DNT;
        this.forumType = f;
        this.instructor = i;
        this.clients = new ArrayList<>();


    }

    public SessionType getSessionType() {
        return sessionType;
    }

    public String getDateNTime() {
        return DateNTime;
    }

    public ForumType getForumType() {
        return forumType;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public List<Client> getClients() {
        return clients;

    }
    public boolean isInTheFuture(){
        String day = this.DateNTime.substring(0,2);
        String month = this.DateNTime.substring(3,5);
        String year = this.DateNTime.substring(6,10);

        int d = Integer.parseInt(day);
        int m = Integer.parseInt(month);
        int y = Integer.parseInt(year);

        LocalDate now = LocalDate.now();
        int dy = (y-now.getYear());
        int dm = (m - now.getMonthValue());
        int dd = (d-now.getDayOfMonth());
        if(dy > 0){
            return true;
        }
        if(dy == 0 && dm > 0){
           return true;
        }
        if(dy == 0 && dm == 0 && dd > 0){
            return true;
        }
        return false;

    }

    @Override
    public String toString() {
        String s = "Session Type: "+sessionType+" | Date: "+DateNTime+" | Forum: "+forumType+" | Instructor: "+instructor.getPerson().getName()+" | Participants: "+clients.size()+"/"+sessionType.getVolume();
        return s;
    }
}

