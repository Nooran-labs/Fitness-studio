package gym.management.Sessions;

public class SessionType {
    public static final SessionType Pilates = new SessionType("Pilates",60,30);
    public static final SessionType MachinePilates = new SessionType("MachinePilates",80,10);
    public static final SessionType ThaiBoxing = new SessionType("ThaiBoxing",100,20);
    public static final SessionType Ninja = new SessionType("Ninja",150,5);

    private final String Type;
    private final int Price;
    private final int Volume;

    private SessionType(String Type,int price,int volume) {
        this.Type = Type;
        this.Price = price;
        this.Volume = volume;
    }

    public String getType() {
        return Type;
    }
    public int getPrice(){
        return Price;
    }
    public int getVolume(){
        return Volume;
    }

    @Override
    public String toString() {
        return Type;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        SessionType sessionType = (SessionType) obj;
        return Type.equals(sessionType.Type);
    }
}

