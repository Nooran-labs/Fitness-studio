package gym.management;

import gym.Exception.*;

import gym.customers.Client;
import gym.customers.Gender;
import gym.management.Sessions.ForumType;
import gym.management.Sessions.Session;
import gym.management.Sessions.SessionType;

import java.util.List;

public class Secretary {
    private boolean active;
    private Person person;
    private int salary;
    private Gym gym;

    public Secretary(Person person, int salary, Gym gym) {
        this.person = person;
        this.salary = salary;
        this.gym = gym;
        active = true;
    }

    public void deactivate() {
        this.active = false;
    }

    public void activate() {
        this.active = true;
    }

    private void validateSecretary() {
        if (!active) {
            throw new NullPointerException();
        }
    }

    public int getSalary() {
        return salary;
    }
    public void addToBalance(int amount){
        person.addToBalance(amount);
    }

    public Client registerClient(Person person) throws DuplicateClientException, InvalidAgeException {
        validateSecretary();
        if (!(gym.getClients().isEmpty())) {
            for (Client clients : gym.getClients()) {
                if (clients.equals(person)) {
                    throw new DuplicateClientException("Error: The client is already registered");
                }

            }
        }


        if (person.getAge() < 18) {
            throw new InvalidAgeException("Error: Client must be at least 18 years old to register");
        }
        Client newClient = new Client(person);
        gym.addClient(newClient);
        gym.getActions().add("Registered new client: " + newClient.getName());
        newClient.addNotification("You have ben registered for the gym successfully");
        return newClient;
    }

    public void unregisterClient(Client client) throws ClientNotRegisteredException {
        validateSecretary();
        if (!gym.getClients().contains(client)) {
            String message = "Error: Registration is required before attempting to unregister";
            System.out.println(message);
            return;
        }
        gym.getClients().remove(client);
        for (Session session : gym.getSessions()){
            session.getClients().remove(client);
        }
        gym.getActions().add("Unregistered client: " + client.getName());
    }

    public Instructor hireInstructor(Person person, int salary, List<SessionType> certifications) {
        validateSecretary();
            if(!(gym.getEvery_register().isEmpty())) {
                for (Client client : gym.getEvery_register()) {
                    Person p1 = client;
                    if (person.equals(p1) || p1.getId() == person.getId()) {
                        Instructor instructor = new Instructor(client, salary, certifications);
                        gym.addInstructor(instructor);
                        gym.getActions().add("Hired new instructor: " + person.getName() + " with salary per hour: " + salary);
                        return instructor;
                    }
                }
            }

        Instructor instructor = new Instructor(person, salary, certifications);
        gym.addInstructor(instructor);
        gym.getActions().add("Hired new instructor: " + person.getName() + " with salary per hour: " + salary);
        return instructor;
    }

    public Session addSession(SessionType type, String dateTime, ForumType forum, Instructor instructor)
            throws InstructorNotQualifiedException {
        validateSecretary();
        if (!instructor.getCertifiedClasses().contains(type)) {
            throw new InstructorNotQualifiedException("Error: Instructor is not qualified to conduct this session type.");
        }
        Session session = new Session(type, dateTime, forum, instructor);
        instructor.addLesson();
        gym.addSession(session);
        gym.getActions().add("Created new session: " + type + " on " + dateTime + " with instructor: " + instructor.getPerson().getName());
        return session;
    }
    public void paySalaries() {
        validateSecretary();
        gym.Pay(this);
        for(Instructor instructor : gym.getInstructors()){
            gym.Pay(instructor);
        }
        gym.getActions().add("Salaries have ben payed to all the workers");
    }

    public void registerClientToLesson(Client client, Session session) throws DuplicateClientException,ClientNotRegisteredException {
        validateSecretary();
        System.out.println("Debug: ForumType is " + session.getForumType());
        System.out.println("Debug: Client Gender is " + client.getGender());
        System.out.println("Debug: isGenderCompatible result: " + session.getForumType().isGenderCompatible(client.getGender()));
        int sessionPrice = session.getSessionType().getPrice();
        if(!(session.isInTheFuture())){
            gym.getActions().add("Failed registration: Session is not in the future");
            return;
        }
        if (!gym.getClients().contains(client)) {
            String massage = "Error: The client is not registered with the gym and cannot enroll in lessons.";
            System.out.println(massage);
            return;
        }
        if (session.getClients().contains(client)){
            throw new DuplicateClientException("Error: The client is already registered to the session ");
        }

            if (!(session.getForumType().isGenderCompatible(client.getGender()))) {
                String massage = "Client's gender doesn't match the session's gender requirements.";
                gym.getActions().add("Failed registration: " + massage);
                System.out.println(massage);
                return;
            }


            if (session.getForumType().equals(ForumType.Seniors) && client.getAge() < 65) {
                String massage = "Client's age doesn't meet the session's requirements (65+).";
                gym.getActions().add("Failed registration: " + massage);
                return;
            }
            if (sessionPrice > client.getBalance()) {
                String message = "Client doesn't have enough balance ";
                gym.getActions().add("Failed registration: " + message);
                return;
            }
            if (session.getSessionType().getVolume() == session.getClients().size()) {
                String massage = "No available spots for session ";
                gym.getActions().add("Failed registration: " + massage);
                return;
            }

            session.getClients().add(client);
            client.subFromBalance(sessionPrice);
            gym.addToBalance(sessionPrice);
            gym.getActions().add("Registered client: " + client.getName() + " to session: " + session.getSessionType() + " on " + session.getDateNTime()+"for price: "+session.getSessionType().getPrice());
            client.addNotification("You have been registered for " + session.getSessionType() + " on " + session.getDateNTime());

    }

    /**
     * This "notify" method notifies all the clients in the gym
     * @param message
     */

    public void notify(String message) {
        validateSecretary();
        for (Client client : gym.getClients()) {
            client.addNotification(message);
        }
        gym.getActions().add("Sent notification to all clients: " + message);
    }

    /**
     * This "notify" method notifies all the clients that are registered to the session
     * @param session
     * @param message
     */
    public void notify(Session session, String message)  {
        validateSecretary();
        for (Client client : session.getClients()) {
            client.addNotification(message);
        }
        gym.getActions().add("A message was sent to everyone registered for session "+session.getSessionType()+" session on "+session.getDateNTime()+" : " + message);
    }

    /**
     * This "notify" method notifies all the clients that have a session at this date
     * @param date
     * @param message
     */
    public void notify(String date,String message)  {
        validateSecretary();
        for (Session session : gym.getSessions()) {
            String Date = session.getDateNTime().substring(0,10);
            if(Date.equals(date)){
                notify(session,message);
            }
        }
    }

    public void printActions() {
        validateSecretary();
        for(int i = 0; i < gym.getActions().size(); i++){
            String action = gym.getActions().get(i);
            System.out.println(action);
        }
    }

    @Override
    public String toString() {
       return  "ID: "+person.getId()+" | Name:"+person.getName()+" | Gender: "+person.getGender()+" | Birthday: "+person.getDateOfBarth()+" | Age: "+person.getAge()+" | Balance: "+person.getBalance()+" | Role: Secretary | Salary per Month: "+salary+"\n";
    }
}


