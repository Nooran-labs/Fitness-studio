package gym.management;

import java.util.List;

import gym.customers.Client;
import gym.management.Sessions.SessionType;


public class Instructor {
    private Person person;
    private int salary;
    private int numOfLessons;
    private final int ID;
    private List<SessionType> certifiedClasses;

    public Instructor(Person person, int salary, List<SessionType> certified){
        this.person = person;
        this.salary = salary;
        this.certifiedClasses = certified;
        this.numOfLessons = 0;
        this.ID = person.getId();
    }

    public Person getPerson() {
        return person;
    }

    public int getSalary() {
        return salary;
    }
    public void getPayed(){
            this.person.addToBalance(salary);
    }

    public List<SessionType> getCertifiedClasses() {
        return certifiedClasses;
    }
    public int getNumOfLessons(){
        return numOfLessons;
    }
    public void addLesson(){
        numOfLessons++;
    }

    public String toString() {
        return "ID: "+ID+" | Name:"+person.getName()+" | Gender: "+person.getGender()+" | Birthday: "+person.getDateOfBarth()+" | Age: "+person.getAge()+" | Balance: "+person.getBalance()+" | Role: Instructor | Salary per Hour: "+getSalary()+" | Certified Classes: "+getCertifiedClasses();

    }
}

