package gym.management;

import gym.customers.Client;
import gym.management.Sessions.Session;
import java.util.ArrayList;
import java.util.List;


public class Gym {

    private static Gym instance;
    private String name;
    private Secretary secretary;
    private int gymBalance;
    private List<Client> clients;
    private List<Instructor> instructors;
    private List<Session> sessions;
    private List<String> actions;
    private List<Client> every_register;

    private Gym() {
        clients = new ArrayList<>();
        instructors = new ArrayList<>();
        sessions = new ArrayList<>();
        actions = new ArrayList<>();
        every_register = new ArrayList<>();
        gymBalance = 0;
    }

    // Singleton implementation
    public static Gym getInstance() {
        if (instance == null) {
            instance = new Gym();
        }
        return instance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Secretary getSecretary() {
        return secretary;
    }

    public void setSecretary(Person person, int salary) {
        if (this.secretary != null) {
            this.secretary.deactivate(); // Deactivate old secretary
        }
        if(!(every_register.isEmpty())) {
            for (Client client : every_register) {
                Person p1 = client;
                if (p1.getId() == person.getId()) {
                    this.secretary = new Secretary(client, salary, this);
                    actions.add("A new secretary has started working at the gym:" + person.getName());
                    return;
                }
            }
        }


        actions.add("A new secretary has started working at the gym:"+ person.getName());
        this.secretary = new Secretary(person, salary, this);
        this.secretary.activate();
    }

    public List<Client> getClients() {
        return clients;
    }
    public List<Client> getEvery_register() {
        return every_register;
    }

    public List<Instructor> getInstructors() {
        return instructors;
    }

    public List<Session> getSessions() {
        return sessions;
    }

    public void addClient(Client client) {

        clients.add(client);
        every_register.add(client);
    }

    public void addInstructor(Instructor instructor) {
        instructors.add(instructor);
    }

    public void addSession(Session session) {
        sessions.add(session);
    }
    public List<String> getActions(){
        return actions;
    }
    public void addToBalance(int money){
        gymBalance = (gymBalance + money);
    }
    public void subFromBalance(int money){
        gymBalance = (gymBalance - money);
    }
    public void Pay(Instructor instructor){
        int salary = instructor.getSalary();
        for (int i = 0; i < instructor.getNumOfLessons(); i++){
            instructor.getPayed();
            subFromBalance(salary);
        }
    }
    public void Pay(Secretary secretary){
        int salary = secretary.getSalary();
        secretary.addToBalance(salary);
        subFromBalance(salary);
    }



    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        // Gym Name
        sb.append("Gym Name: ").append(name).append("\n");

        // Gym Secretary
        sb.append("Gym Secretary: ").append(secretary != null ? secretary.toString() : "No secretary assigned").append("\n");

        // Gym Balance
        sb.append("Gym Balance: ").append(gymBalance).append("\n");

        // Clients Data
        sb.append("\nClients Data:\n");
        for (Client client : clients) {
            sb.append(client.toString()).append("\n");
        }

        // Employees Data
        sb.append("\nEmployees Data:\n");
        for (Instructor instructor : instructors) {
            sb.append(instructor.toString()).append("\n");
        }
        if (secretary != null) {
            sb.append(secretary.toString()).append("\n");
        }

        // Sessions Data
        sb.append("\nSessions Data:\n");
        for (Session session : sessions) {
            sb.append(session.toString()).append("\n");
        }

        return sb.toString();
    }

}
