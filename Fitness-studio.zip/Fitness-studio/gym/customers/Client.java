package gym.customers;

import gym.management.Person;
import java.util.ArrayList;
import java.util.List;


public class Client extends Person {
    private int ID;
    private List<String> notifications;

    public Client(Person person) {
        super(person.getName(), person.getBalance(), person.getGender(), person.getDateOfBarth());
        this.notifications = new ArrayList<>();
        this.ID = person.getId();
    }

    public List<String> getNotifications() {
        return notifications;
    }

    public void addNotification(String message) {
        notifications.add(message);
    }

    @Override
    public String toString() {
        return "ID: "+ID+" | Name:"+getName()+" | Gender: "+getGender()+" | Birthday: "+getDateOfBarth()+" | Age: "+getAge()+" | Balance: "+getBalance();

    }
}
