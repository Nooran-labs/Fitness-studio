package gym.customers;

public class Gender {
    private final String gender;

    public static final Gender Male = new Gender("Male");
    public static final Gender Female = new Gender("Female");

    private Gender(String gender) {
        this.gender = gender;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Gender gender1 = (Gender) obj;
        return gender.equals(gender1.gender);
    }

    public String toString() {
        return gender;
    }
}
